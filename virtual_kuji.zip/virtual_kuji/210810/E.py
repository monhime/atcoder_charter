import sys
def input(): return sys.stdin.readline().rstrip()
def main():
    

if __name__=='__main__':
    main()